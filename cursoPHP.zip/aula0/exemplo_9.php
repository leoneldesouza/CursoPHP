<?php

define ('PI', 3.1415);
define ('BASEPATH', "/srv/www");

echo PI ."\n";
echo BASEPATH ."\n";
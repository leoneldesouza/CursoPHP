<?php

$a = 2;
$b = 2;
$c = 2;
$d = 2;

echo $a++;
echo $a;
echo ++$b;

echo $c--;
echo $c;
echo --$d;


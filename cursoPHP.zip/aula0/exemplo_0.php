<?php 
	//Um comentario

	# Outro comentario

	/*
	*Comentario de varias linhas
	*/

	// Imprime na tela a palavra Ola Mundo


	$nome = "Leonel";
	echo "\nOla, ${nome}s \n\n";

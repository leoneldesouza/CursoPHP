<?php
// Operadores matematicos avancados

$a = 10;
$b = 3;

echo $a % $b ."\n";

$random = rand();
$resultado = $random % 100;

echo "($random) => $resultado" . "\n";

$random = rand();
$resultado = $random % 2;

echo "($random) => $resultado" . "\n";
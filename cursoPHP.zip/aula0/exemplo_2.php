<?php

// Operadores matematicos basicos

$a = 2;
$b = 4;
$soma = $a+$b;
$subtracao = $a-$b;
$divisao = $a/$b;
$multiplicacao = $a*$b;

echo "$a + $b = " . $soma ."\n";
echo "$a - $b = " . $subtracao ."\n";
echo "$a * $b = " . $multiplicacao ."\n";
echo "$a / $b = " . $divisao ."\n";
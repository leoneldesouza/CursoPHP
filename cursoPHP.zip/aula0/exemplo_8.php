<?php
include "exemplo_0.php";

print("aqui 1")  ."\n\n";

require "exemplo_0.php";

print ("aqui 2") ."\n\n";
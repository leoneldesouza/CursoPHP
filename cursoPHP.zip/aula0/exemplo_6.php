<?php

$a = 7 == 7; // igual
$b = 7 != 7; // diferente
$c = "7" === 7; // identico
$d = 7 !== 8; // nao identico
$e = 7 > 8; // maior que
$f = 7 < 8; // menor que
$g = 7 <= 8; // menor ou igual a
$h = 7 >= 8; // maior ou igual a 

var_dump($a);
var_dump($b);
var_dump($c);
var_dump($d);
var_dump($e);
var_dump($f);
var_dump($g);
var_dump($h);

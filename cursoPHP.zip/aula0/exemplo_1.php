<?php

	// todo: descrever o que vai fazer mais adiante.

$string = "String";
$inteiro = 10;
$float = 10+2;
$array =[5, 15];
$sub_array =["Azul", "Amarelo", "Rosa"];
$array2 =[$array];

//var_dump($string);

//var_dump($array, $array, $sub_array);

echo $array[0]; 




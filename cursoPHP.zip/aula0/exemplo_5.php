<?php

$a = 4;
$b = 4;
$b = 4;
$c = 4;

echo $a++;
echo ++$b;

echo $c--;
echo --$d;


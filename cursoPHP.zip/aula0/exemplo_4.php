<?php

//

$a = 10;
$b = 10;
$p = 3.7;
$resultado = $a + $b;

 //todo: pegar a variavel resultado e diminuir a porcentagem
 $resultado = $resultado - $p;
 $resultado -= $p;
echo $resultado . "\n"; 
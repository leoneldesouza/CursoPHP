<?php

$expression = false;

while($expression){
	echo "[Wile] Oi, eu souza Goku!!\n";
}

do {
	echo "[Do Wile] Oi, eu souza Goku!!\n";
}while ($expression);
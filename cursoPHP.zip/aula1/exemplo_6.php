<?php

// For de 0 a 20

for($i = 0; $i <= 20; $i++){
	echo "Contador: $i\n";
}

echo "\n+=============FOR-1===============+\n";

//For de 20 a 0

for($i = 20; $i >= 0; $i--){
	echo "Contador: $i\n";
}

echo "\n+=============FOR-20===============+\n";
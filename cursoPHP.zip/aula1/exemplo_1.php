<?php

// estruturas de decisao

$num1 = 10;
$num2 = 6;

if($num1==$num2){
	echo "Os numeros sao iguais \n";
}
else{
	echo "Os numeros nao sao iguais\n";
}

echo "Obrigado, ate logo !!\n";
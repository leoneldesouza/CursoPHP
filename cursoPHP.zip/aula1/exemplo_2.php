<?php

// estruturas de decisao

$num1 = 10;
$num2 = 6;

if($num1 == $num2){
	echo "o numero num1 e igual ao num2 \n";
}
else if($num1 > $num2){
	echo "O num1 e maior que num2\n";
}else if($num1 < $num2){
	echo "O num1 e menor que num2\n";
}else{
	echo "Os numeros sao diferentes\n";
}

echo "Obrigado, ate logo !!\n";